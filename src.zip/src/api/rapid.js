import { http } from "./http";

export const rapidApi = async url => {
  return http(url, {
    "x-rapidapi-key": "899091d528msh0928de647033958p153603jsnca6c15a4909d",
    "x-rapidapi-host": "booking-com15.p.rapidapi.com"
  });
}