// Home.js

import React from 'react';
import Destination from './Destination';
import Hotels from './Hotels'; 
import Car from './Car';
import './Home.css';

const Home = () => {
  return (
    <div className="home-container">
      <h1>Travel around, don't stay</h1>
      <Destination />
      <Hotels /> {/* Update component name */}
      <Car/>
    </div>
  );
};

export default Home;
